-- Backup: 2026-09-16 11:59:51
-- DB: company_rating_saas

CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` VALUES ('1','admin','$2y$10$jEKODXNcBvreD9z/aAPVtueCcvNgfwO8/hqeEieYqDBLxjkd0Qtg2','admin@example.com','2026-09-01 12:50:35');

CREATE TABLE `analytics_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `event_type` varchar(40) NOT NULL,
  `event_category` varchar(60) DEFAULT NULL,
  `event_label` varchar(255) DEFAULT NULL,
  `traffic_source` varchar(50) NOT NULL DEFAULT 'direct',
  `utm_source` varchar(60) DEFAULT NULL,
  `utm_medium` varchar(60) DEFAULT NULL,
  `utm_campaign` varchar(100) DEFAULT NULL,
  `utm_content` varchar(100) DEFAULT NULL,
  `click_id` varchar(120) DEFAULT NULL,
  `page_url` varchar(255) DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  `session_id` varchar(64) DEFAULT NULL,
  `visitor_ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `device_type` varchar(20) DEFAULT 'desktop',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_created` (`tenant_id`,`created_at`),
  KEY `idx_comp_event_created` (`company_id`,`event_type`,`created_at`),
  KEY `idx_type_created` (`event_type`,`created_at`),
  KEY `idx_source` (`traffic_source`),
  KEY `idx_utm_camp` (`tenant_id`,`utm_campaign`),
  KEY `idx_click_id` (`click_id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `analytics_events` VALUES ('1','1','1','page_view','rating_page','Home Rating Page','direct','','','','','','/rate/index.php','','test_sess_6a9f005438742','192.168.1.50','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','desktop','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('2','1','1','page_view','rating_page','QR Scan Visit','qr','','','','','','/rate/index.php?src=qr','','test_sess_6a9f00543a145','192.168.1.51','Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1','mobile','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('3','1','1','qr_scan','qr_stand','Front Desk Counter Stand','qr','','','','','','/rate/index.php?src=qr','','test_sess_6a9f00543a145','192.168.1.51','Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1','mobile','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('4','1','1','whatsapp_click','floating_button','Floating WhatsApp','direct','','','','','','/rate/index.php','','test_sess_6a9f005438742','192.168.1.50','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','desktop','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('5','1','1','whatsapp_click','review_inquiry','Inquire on Review #1','direct','','','','','','/rate/index.php','','test_sess_6a9f00543a145','192.168.1.51','Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1','mobile','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('6','1','1','form_start','review_form','User Started Review','qr','','','','','','/rate/index.php?src=qr','','test_sess_6a9f00543a145','192.168.1.51','Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1','mobile','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('7','1','1','review_submit','general_review','General Review Form','qr','','','','','','/rate/index.php?src=qr','','test_sess_6a9f00543a145','192.168.1.51','Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1','mobile','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('8','1','1','whatsapp_click','qa_inquiry','Community Q&A Inquiry #3','qr','','','','','','','','','127.0.0.1','','desktop','2026-09-07 20:20:04');
INSERT INTO `analytics_events` VALUES ('9','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 20:22:41');
INSERT INTO `analytics_events` VALUES ('10','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 20:36:22');
INSERT INTO `analytics_events` VALUES ('11','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 22:46:27');
INSERT INTO `analytics_events` VALUES ('12','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 22:47:09');
INSERT INTO `analytics_events` VALUES ('13','3','4','whatsapp_click','floating_button','Floating Sticky WhatsApp','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 22:47:20');
INSERT INTO `analytics_events` VALUES ('14','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 23:56:39');
INSERT INTO `analytics_events` VALUES ('15','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-07 23:56:54');
INSERT INTO `analytics_events` VALUES ('16','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-08 00:24:50');
INSERT INTO `analytics_events` VALUES ('17','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-08 10:12:01');
INSERT INTO `analytics_events` VALUES ('18','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-08 10:20:17');
INSERT INTO `analytics_events` VALUES ('19','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-08 10:36:41');
INSERT INTO `analytics_events` VALUES ('20','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-08 10:42:48');
INSERT INTO `analytics_events` VALUES ('21','3','4','form_start','review_form','User Started Review','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-08 10:43:00');
INSERT INTO `analytics_events` VALUES ('23','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 20:33:30');
INSERT INTO `analytics_events` VALUES ('24','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 21:53:43');
INSERT INTO `analytics_events` VALUES ('25','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 22:48:49');
INSERT INTO `analytics_events` VALUES ('26','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=questions','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 23:15:48');
INSERT INTO `analytics_events` VALUES ('27','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 23:16:27');
INSERT INTO `analytics_events` VALUES ('28','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 23:18:33');
INSERT INTO `analytics_events` VALUES ('29','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-10 23:20:37');
INSERT INTO `analytics_events` VALUES ('30','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','desktop','2026-09-11 09:54:47');
INSERT INTO `analytics_events` VALUES ('31','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 13:16:06');
INSERT INTO `analytics_events` VALUES ('32','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 14:15:28');
INSERT INTO `analytics_events` VALUES ('33','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 14:15:28');
INSERT INTO `analytics_events` VALUES ('34','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 14:44:13');
INSERT INTO `analytics_events` VALUES ('35','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 14:44:13');
INSERT INTO `analytics_events` VALUES ('36','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 14:45:40');
INSERT INTO `analytics_events` VALUES ('37','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:03:33');
INSERT INTO `analytics_events` VALUES ('38','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:03:33');
INSERT INTO `analytics_events` VALUES ('39','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:04:28');
INSERT INTO `analytics_events` VALUES ('40','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:04:28');
INSERT INTO `analytics_events` VALUES ('41','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:07:00');
INSERT INTO `analytics_events` VALUES ('42','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:07:00');
INSERT INTO `analytics_events` VALUES ('43','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:28:32');
INSERT INTO `analytics_events` VALUES ('44','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:28:32');
INSERT INTO `analytics_events` VALUES ('45','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:30:39');
INSERT INTO `analytics_events` VALUES ('46','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:30:39');
INSERT INTO `analytics_events` VALUES ('47','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:30:47');
INSERT INTO `analytics_events` VALUES ('48','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:30:47');
INSERT INTO `analytics_events` VALUES ('49','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:31:05');
INSERT INTO `analytics_events` VALUES ('50','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 15:31:05');
INSERT INTO `analytics_events` VALUES ('51','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 16:40:51');
INSERT INTO `analytics_events` VALUES ('52','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 16:40:51');
INSERT INTO `analytics_events` VALUES ('53','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 16:54:10');
INSERT INTO `analytics_events` VALUES ('54','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 16:54:10');
INSERT INTO `analytics_events` VALUES ('55','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 16:54:19');
INSERT INTO `analytics_events` VALUES ('56','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 16:54:19');
INSERT INTO `analytics_events` VALUES ('57','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 17:02:54');
INSERT INTO `analytics_events` VALUES ('58','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 17:02:54');
INSERT INTO `analytics_events` VALUES ('59','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 17:08:01');
INSERT INTO `analytics_events` VALUES ('60','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 17:08:01');
INSERT INTO `analytics_events` VALUES ('61','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 20:04:42');
INSERT INTO `analytics_events` VALUES ('62','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 20:04:42');
INSERT INTO `analytics_events` VALUES ('63','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 20:04:46');
INSERT INTO `analytics_events` VALUES ('64','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 20:04:46');
INSERT INTO `analytics_events` VALUES ('65','3','10','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 20:15:06');
INSERT INTO `analytics_events` VALUES ('66','3','10','page_view','rating_page','Rate Airport West Hotel-Aniella Restaurant - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 22:00:00');
INSERT INTO `analytics_events` VALUES ('67','3','10','page_view','rating_page','Rate Airport West Hotel-Aniella Restaurant - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 22:00:36');
INSERT INTO `analytics_events` VALUES ('68','3','10','page_view','rating_page','Rate Airport West Hotel-Aniella Restaurant - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 22:06:47');
INSERT INTO `analytics_events` VALUES ('69','3','4','page_view','rating_page','Rate Airport West Hotel - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 23:32:49');
INSERT INTO `analytics_events` VALUES ('70','3','4','form_start','review_form','User Started Review','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=4#tab=feedbacks','http://localhost:8080/rate/companies.php','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 23:33:55');
INSERT INTO `analytics_events` VALUES ('71','3','10','page_view','rating_page','Rate Airport West Hotel-Aniella Restaurant - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-14 23:34:17');
INSERT INTO `analytics_events` VALUES ('72','3','10','page_view','rating_page','Rate Airport West Hotel-Aniella Restaurant - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:30:38');
INSERT INTO `analytics_events` VALUES ('73','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:35:49');
INSERT INTO `analytics_events` VALUES ('74','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:35:49');
INSERT INTO `analytics_events` VALUES ('75','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:36:23');
INSERT INTO `analytics_events` VALUES ('76','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:36:23');
INSERT INTO `analytics_events` VALUES ('77','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:52:24');
INSERT INTO `analytics_events` VALUES ('78','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:52:25');
INSERT INTO `analytics_events` VALUES ('79','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:55:39');
INSERT INTO `analytics_events` VALUES ('80','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:55:39');
INSERT INTO `analytics_events` VALUES ('81','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:59:54');
INSERT INTO `analytics_events` VALUES ('82','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 09:59:55');
INSERT INTO `analytics_events` VALUES ('83','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 11:03:28');
INSERT INTO `analytics_events` VALUES ('84','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 11:03:28');
INSERT INTO `analytics_events` VALUES ('85','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 11:03:36');
INSERT INTO `analytics_events` VALUES ('86','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 11:03:36');
INSERT INTO `analytics_events` VALUES ('87','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 12:44:01');
INSERT INTO `analytics_events` VALUES ('88','3','4','widget_view','embed_widget','card','widget','','','','','','','','','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 12:44:01');
INSERT INTO `analytics_events` VALUES ('89','3','10','page_view','rating_page','Rate Airport West Hotel-Aniella Restaurant - Verified Ratings &amp; Reviews','direct','','','','','','http://localhost:8080/rate/rate/index.php?company=10&amp;tenant=airport-west-hotel-aniella-restaurant','http://localhost:8080/rate/admin/company.php?company=10','v_9u56qy3abmsmtrkixyp','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','desktop','2026-09-15 12:55:29');

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` VALUES ('1','Technology','2026-09-01 12:50:35');
INSERT INTO `categories` VALUES ('2','Healthcare','2026-09-01 12:50:35');
INSERT INTO `categories` VALUES ('3','Finance','2026-09-01 12:50:35');
INSERT INTO `categories` VALUES ('4','Retail','2026-09-01 12:50:35');
INSERT INTO `categories` VALUES ('5','Manufacturing','2026-09-01 12:50:35');
INSERT INTO `categories` VALUES ('6','Hospitality','2026-09-04 11:00:19');

CREATE TABLE `community_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(30) DEFAULT NULL,
  `question_text` text NOT NULL,
  `official_answer` text DEFAULT NULL,
  `answered_by` int(11) DEFAULT NULL,
  `answered_at` datetime DEFAULT NULL,
  `helpful_count` int(11) NOT NULL DEFAULT 0,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('published','pending','hidden') NOT NULL DEFAULT 'published',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_comp_status` (`company_id`,`status`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_pinned` (`is_pinned`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `community_questions` VALUES ('1','1','1','Kofi Mensah','kofi@example.com','233241234567','Do you provide airport shuttle pickups on weekends?','Yes! Airport West Hotel provides complimentary airport shuttle pickups 24/7 for all checked-in guests. Please inform front desk 2 hours prior to arrival.','1','2026-09-07 20:11:33','1','1','published','2026-09-07 20:11:33');
INSERT INTO `community_questions` VALUES ('2','1','1','Management FAQ','','','What are the breakfast hours?','Buffet breakfast is served every morning from 6:30 AM to 10:30 AM in the main terrace restaurant.','1','2026-09-07 20:11:37','0','1','published','2026-09-07 20:11:37');
INSERT INTO `community_questions` VALUES ('3','1','1','Kofi Mensah','kofi@example.com','233241234567','Do you provide airport shuttle pickups on weekends?','Yes! Airport West Hotel provides complimentary airport shuttle pickups 24/7 for all checked-in guests. Please inform front desk 2 hours prior to arrival.','1','2026-09-07 20:12:40','1','1','published','2026-09-07 20:12:40');
INSERT INTO `community_questions` VALUES ('4','1','1','Management FAQ','','','What are the breakfast hours?','Buffet breakfast is served every morning from 6:30 AM to 10:30 AM in the main terrace restaurant.','1','2026-09-07 20:12:42','0','1','published','2026-09-07 20:12:42');
INSERT INTO `community_questions` VALUES ('5','1','1','Kofi Mensah','kofi@example.com','233241234567','Do you provide airport shuttle pickups on weekends?','Yes! Airport West Hotel provides complimentary airport shuttle pickups 24/7 for all checked-in guests. Please inform front desk 2 hours prior to arrival.','1','2026-09-07 20:13:18','1','1','published','2026-09-07 20:13:18');
INSERT INTO `community_questions` VALUES ('6','1','1','Management FAQ','','','What are the breakfast hours?','Buffet breakfast is served every morning from 6:30 AM to 10:30 AM in the main terrace restaurant.','1','2026-09-07 20:13:18','0','1','published','2026-09-07 20:13:18');
INSERT INTO `community_questions` VALUES ('7','1','1','Ama Osei','ama@example.com','233244112233','Can we book the conference hall for 50 guests on Saturday?','','','','0','0','published','2026-09-07 20:13:18');
INSERT INTO `community_questions` VALUES ('8','1','1','Kofi Mensah','kofi@example.com','233241234567','Do you provide airport shuttle pickups on weekends?','Yes! Airport West Hotel provides complimentary airport shuttle pickups 24/7 for all checked-in guests. Please inform front desk 2 hours prior to arrival.','1','2026-09-07 20:13:30','1','1','published','2026-09-07 20:13:30');
INSERT INTO `community_questions` VALUES ('9','1','1','Management FAQ','','','What are the breakfast hours?','Buffet breakfast is served every morning from 6:30 AM to 10:30 AM in the main terrace restaurant.','1','2026-09-07 20:13:30','0','1','published','2026-09-07 20:13:30');
INSERT INTO `community_questions` VALUES ('10','1','1','Ama Osei','ama@example.com','233244112233','Can we book the conference hall for 50 guests on Saturday?','','','','1','0','published','2026-09-07 20:13:30');
INSERT INTO `community_questions` VALUES ('11','3','4','Edward Mensah','e.mensah@ghanabiz.org','','Do you provide complimentary airport shuttle pickups to Kotoka Airport (ACC)?','Yes! Airport West Hotel provides complimentary 24/7 airport shuttle service to and from Kotoka International Airport (ACC) for all our registered guests. Kindly share your flight number and arrival time at least 2 hours in advance so our chauffeur can meet you promptly at Arrivals.','','2026-09-06 11:00:00','13','0','published','2026-09-05 16:30:00');
INSERT INTO `community_questions` VALUES ('12','3','4','Sarah Jenkins','s.jenkins@expatsgh.org','','What are the breakfast hours and what dining options are available?','Our complimentary buffet breakfast is served every morning from 6:30 AM to 10:30 AM at the terrace restaurant. We offer international continental breakfast along with hot Ghanaian specialties. Room service and our terrace bar are open 24/7.','','2026-09-06 11:00:00','8','0','published','2026-09-05 16:30:00');
INSERT INTO `community_questions` VALUES ('13','3','4','David Osei','david.osei@transcorp.com','','What are your check-in and check-out times, and can I request early check-in?','Standard check-in begins at 2:00 PM and check-out is by 12:00 PM (noon). Early check-in or late check-out requests are accommodated subject to room availability on the day. You can also message our front desk on WhatsApp before arrival!','','2026-09-06 11:00:00','15','0','published','2026-09-05 16:30:00');

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `whatsapp_number` varchar(30) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `google_store_url` varchar(500) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `booster_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `booster_min_stars` tinyint(1) NOT NULL DEFAULT 4,
  `google_map_url` varchar(1000) DEFAULT NULL COMMENT 'Google Maps direction / location URL',
  `map_embed_code` text DEFAULT NULL COMMENT 'Google Map embed iframe code or embed URL',
  `location_description` text DEFAULT NULL COMMENT 'Location directions and landmark description',
  `facebook_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `tiktok_url` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tenant_id` (`tenant_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customers_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customers` VALUES ('1','1','Tech Solutions Inc','1','info@techsolutions.com','','','www.techsolutions.com','2026-09-01 12:50:36','https://g.page/r/test-business/review','','','1','4','','','','','','','','','');
INSERT INTO `customers` VALUES ('2','1','Health Care Plus','2','contact@healthcareplus.com','','','www.healthcareplus.com','2026-09-01 12:50:36','','','','1','4','','','','','','','','','');
INSERT INTO `customers` VALUES ('3','2','Finance Pro','3','support@financepro.com','','','www.financepro.com','2026-09-01 12:50:36','','','','1','4','','','','','','','','','');
INSERT INTO `customers` VALUES ('4','3','Airport West Hotel','6','IT@airportwesthotel.com.gh','+233245834338','+233245834338','https://airportwesthotel.com','2026-09-04 12:56:35','https://search.google.com/local/writereview?placeid=ChIJAirportWestHotelAccra','138 Airport West, 10 Senchi Street, Airport Residential Area, Accra, Ghana','Airport West Hotel is a premier boutique hotel situated in Accra\'s serene Airport Residential Area, just 5 minutes from Kotoka International Airport (ACC). Featuring executive suites, complimentary 24/7 airport shuttles, terrace restaurant, outdoor pool, and modern meeting facilities.','1','4','https://www.google.com/maps/dir/?api=1&destination=Airport+West+Hotel+10+Senchi+Street+Airport+Residential+Area+Accra+Ghana','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3970.6482705141974!2d-0.1873177!3d5.6183664!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf9b036573c091%3A0xb35a0928a6fcf7c7!2sAirport%20West%20Hotel!5e0!3m2!1sen!2sgh!4v1710000000000!5m2!1sen!2sgh\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>','Situated in the serene Airport Residential Area on 10 Senchi Street, Accra. Located just 5 minutes from Kotoka International Airport (ACC) and 3 minutes from Accra Mall. Features 24/7 guarded private parking for all guests and visitors.','https://facebook.com/airportwesthotel','https://instagram.com/airportwesthotel','https://twitter.com/airportwesthotel','https://linkedin.com/company/airport-west-hotel','https://tiktok.com/@airportwesthotel','https://youtube.com/@airportwesthotel');
INSERT INTO `customers` VALUES ('5','4','Test Flow Company 229','','test_quote_8e5be436@example.com','+1234567890','','','2026-09-11 07:16:01','','','','1','4','','','','','','','','','');
INSERT INTO `customers` VALUES ('6','5','Test Flow Company 386','','test_quote_27a75588@example.com','+1234567890','','','2026-09-11 07:16:46','','','','1','4','','','','','','','','','');
INSERT INTO `customers` VALUES ('7','6','Test Flow Company 155','','test_quote_c9f698ac@example.com','+1234567890','','','2026-09-11 07:17:04','','','','1','4','','','','','','','','','');
INSERT INTO `customers` VALUES ('10','3','Airport West Hotel-Aniella Restaurant','6','IT@airportwesthotel.com.gh','+233245834338','233554552456','airportwesthotel.com.gh','2026-09-14 18:14:30','','','','1','4','','','','','','','','','');

CREATE TABLE `helpful_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating_id` int(11) NOT NULL,
  `voter_ip` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_vote` (`rating_id`,`voter_ip`),
  CONSTRAINT `helpful_votes_ibfk_1` FOREIGN KEY (`rating_id`) REFERENCES `ratings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `payment_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gateway_key` varchar(40) DEFAULT NULL,
  `event_type` varchar(80) DEFAULT NULL,
  `reference` varchar(120) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `signature_valid` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `payload` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_event_gateway` (`gateway_key`),
  KEY `idx_event_reference` (`reference`),
  KEY `idx_event_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_key` varchar(40) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `mode` enum('test','live') NOT NULL DEFAULT 'test',
  `public_key` varchar(255) DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `webhook_secret` varchar(255) DEFAULT NULL,
  `currency` varchar(8) NOT NULL DEFAULT 'GHS',
  `bank_name` varchar(140) DEFAULT NULL,
  `account_name` varchar(140) DEFAULT NULL,
  `account_number` varchar(80) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `connection_status` varchar(20) NOT NULL DEFAULT 'unverified',
  `connection_note` varchar(255) DEFAULT NULL,
  `last_checked_at` datetime DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_gateway_key` (`gateway_key`),
  KEY `idx_gateway_enabled` (`is_enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_gateways` VALUES ('1','paystack','Paystack','0','test','','','','USD','','','','Cards, mobile money, bank transfer and USSD across Ghana, Nigeria, Kenya and South Africa.','unverified','Not configured yet.','','1','2026-09-15 18:14:43','2026-09-15 18:14:43');
INSERT INTO `payment_gateways` VALUES ('2','flutterwave','Flutterwave','0','test','','','','USD','','','','Cards, mobile money, bank accounts and Barion wallets in 30+ African markets.','unverified','Not configured yet.','','2','2026-09-15 18:14:43','2026-09-15 18:14:43');
INSERT INTO `payment_gateways` VALUES ('3','bank_transfer','Bank transfer / Manual','0','test','','','','USD','','','','Publish bank or mobile-money details, then confirm the transfer yourself before the plan activates.','unverified','Not configured yet.','','3','2026-09-15 18:14:43','2026-09-15 18:14:43');

CREATE TABLE `payment_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(40) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `purpose` enum('new','renewal','upgrade','downgrade','addon') NOT NULL DEFAULT 'renewal',
  `subject` varchar(190) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(8) NOT NULL DEFAULT '',
  `months` int(11) NOT NULL DEFAULT 12,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `status` enum('draft','open','processing','paid','overdue','cancelled','refunded') NOT NULL DEFAULT 'open',
  `gateway_key` varchar(40) DEFAULT NULL,
  `checkout_reference` varchar(120) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `issued_by` varchar(120) DEFAULT NULL,
  `confirmed_by` varchar(120) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_invoice_number` (`invoice_number`),
  KEY `idx_invoice_tenant` (`tenant_id`),
  KEY `idx_invoice_status` (`status`),
  KEY `idx_invoice_created` (`created_at`),
  KEY `idx_invoice_reference` (`checkout_reference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `payment_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(8) NOT NULL DEFAULT '',
  `kind` enum('refund','credit') NOT NULL DEFAULT 'refund',
  `reason` varchar(255) DEFAULT NULL,
  `status` enum('pending','processed','rejected') NOT NULL DEFAULT 'pending',
  `gateway_key` varchar(40) DEFAULT NULL,
  `gateway_reference` varchar(120) DEFAULT NULL,
  `requested_by` varchar(120) DEFAULT NULL,
  `processed_by` varchar(120) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_refund_tenant` (`tenant_id`),
  KEY `idx_refund_payment` (`payment_id`),
  KEY `idx_refund_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `qa_helpful_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `voter_ip` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_qa_vote` (`question_id`,`voter_ip`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `qa_helpful_votes` VALUES ('1','1','192.168.1.100','2026-09-07 20:11:36');
INSERT INTO `qa_helpful_votes` VALUES ('2','3','192.168.1.100','2026-09-07 20:12:41');
INSERT INTO `qa_helpful_votes` VALUES ('3','5','192.168.1.100','2026-09-07 20:13:18');
INSERT INTO `qa_helpful_votes` VALUES ('4','8','192.168.1.100','2026-09-07 20:13:30');
INSERT INTO `qa_helpful_votes` VALUES ('5','10','192.168.1.200','2026-09-07 20:13:30');
INSERT INTO `qa_helpful_votes` VALUES ('6','11','::1','2026-09-07 21:47:52');

CREATE TABLE `quote_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `public_id` varchar(32) DEFAULT NULL,
  `converted_tenant_id` int(11) DEFAULT NULL,
  `setup_email_sent` tinyint(1) NOT NULL DEFAULT 0,
  `setup_token` varchar(128) DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `num_companies` int(11) DEFAULT NULL,
  `expected_ratings` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','contacted','converted','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_quote_public_id` (`public_id`),
  KEY `category_id` (`category_id`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `quote_requests_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quote_requests_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `quote_requests` VALUES ('1','QTE-WP2EP9V4','','0','','Airport West Hotel','Theophilus Akakpo','IT@airportwesthotel.com.gh','+233245834338','airportwesthotel.com.gh','6','1','Accra-Dzorwulu','1','100','','converted','2026-09-04 11:03:16');
INSERT INTO `quote_requests` VALUES ('3','QTE-HD85C5WN','4','1','','Test Flow Company 229','John Tester','test_quote_8e5be436@example.com','+1234567890','https://example.com','1','1','Accra, Ghana','1','100','Testing Real ID flow','converted','2026-09-11 07:15:59');
INSERT INTO `quote_requests` VALUES ('4','QTE-76EFCASC','5','1','','Test Flow Company 386','John Tester','test_quote_27a75588@example.com','+1234567890','https://example.com','1','1','Accra, Ghana','1','100','Testing Real ID flow','converted','2026-09-11 07:16:44');
INSERT INTO `quote_requests` VALUES ('5','QTE-N4TR8BHX','6','1','','Test Flow Company 155','John Tester','test_quote_c9f698ac@example.com','+1234567890','https://example.com','1','1','Accra, Ghana','1','100','Testing Real ID flow','converted','2026-09-11 07:17:03');

CREATE TABLE `rating_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `question_text` varchar(500) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `tenant_id` (`tenant_id`),
  KEY `idx_rq_comp` (`company_id`),
  CONSTRAINT `rating_questions_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rating_questions` VALUES ('1','1','','How satisfied are you with the speed and responsiveness of our technical support team?','1','2026-09-03 19:47:46');
INSERT INTO `rating_questions` VALUES ('2','1','','How would you rate the quality and reliability of our technology solutions?','1','2026-09-03 19:47:46');
INSERT INTO `rating_questions` VALUES ('3','1','','How likely are you to recommend Tech Solutions Inc to colleagues or other businesses?','1','2026-09-03 19:47:46');
INSERT INTO `rating_questions` VALUES ('5','1','','How is the strengh of our internet serviece','1','2026-09-04 10:40:43');
INSERT INTO `rating_questions` VALUES ('6','3','','How was your nigh and experience with Airport West Hotel','1','2026-09-04 11:12:52');
INSERT INTO `rating_questions` VALUES ('7','3','','Rate the promotions','1','2026-09-04 13:36:19');

CREATE TABLE `rating_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL DEFAULT 'Guest',
  `user_email` varchar(100) DEFAULT NULL,
  `reply_text` text NOT NULL,
  `is_official` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_rating` (`rating_id`),
  KEY `idx_company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `customer_name` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `comment` text DEFAULT NULL,
  `photos` text DEFAULT NULL COMMENT 'JSON array of photo paths',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_reply` text DEFAULT NULL,
  `helpful_count` int(11) DEFAULT 0,
  `reported` tinyint(1) DEFAULT 0,
  `responded_at` timestamp NULL DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `verification_type` varchar(30) DEFAULT NULL,
  `momo_ref` varchar(100) DEFAULT NULL,
  `receipt_photo` varchar(255) DEFAULT NULL,
  `is_escalated` tinyint(1) NOT NULL DEFAULT 0,
  `escalation_status` varchar(20) NOT NULL DEFAULT 'none',
  `service_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ratings` VALUES ('5','1','1','5','Michael Scott','michael@dundermifflin.com','Tech support team answered in under 2 minutes and fixed everything!','','2026-09-03 19:52:47','','0','0','','0','','','','0','none','');
INSERT INTO `ratings` VALUES ('6','1','1','4','sssddssd','sdfsdfsf@gmail.com','fsfsfsss','','2026-09-04 10:46:25','We thank you for your time and review and we would improve on it','0','0','2026-09-04 10:50:54','0','','','','0','none','');
INSERT INTO `ratings` VALUES ('7','4','6','4','Amina Bello','','Very serene atmosphere in the Airport Residential Area. Courteous staff, clean pool terrace, and pleasant room service. The check-in was smooth and food was tasty. A peaceful oasis close to the airport.','','2026-09-04 13:39:35','Thank you Amina for staying with us and for sharing your experience! We\'re thrilled you enjoyed our serene terrace and courteous team.','0','0','2026-09-06 09:15:00','1','Receipt','','','0','none','');
INSERT INTO `ratings` VALUES ('8','4','7','5','Dr. Michael Mensah','','Excellent stay at Airport West Hotel! The 24/7 complimentary airport shuttle was prompt and stress-free after my late flight into Kotoka. Spotless executive room, ultra-fast Wi-Fi, and delicious breakfast buffet. Will definitely be returning for my next Accra conference.','','2026-09-04 13:39:35','Thank you Dr. Mensah for your generous 5-star review! We are delighted that you enjoyed our airport shuttle and executive room. We look forward to hosting you on your next trip to Accra.','0','0','2026-09-05 10:30:00','1','MoMo','MTN-99482104','','0','none','');
INSERT INTO `ratings` VALUES ('14','4','','5','Kwame Kwarteng','kwame.k@investgh.com','Exceptional hospitality. Staff carried my luggage immediately, check-in took 2 minutes, and the breakfast spread had authentic local options. Highly recommended!','','2026-09-06 14:20:00','','0','0','','1','MoMo','VOD-7738201','','0','none','');

CREATE TABLE `reported_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rating_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `reporter_ip` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `rating_id` (`rating_id`),
  CONSTRAINT `reported_reviews_ibfk_1` FOREIGN KEY (`rating_id`) REFERENCES `ratings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `review_invites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) NOT NULL,
  `customer_phone` varchar(30) NOT NULL,
  `order_ref` varchar(100) DEFAULT NULL,
  `template_key` varchar(50) NOT NULL,
  `invite_message` text NOT NULL,
  `channel` varchar(20) NOT NULL DEFAULT 'whatsapp',
  `status` varchar(20) NOT NULL DEFAULT 'sent',
  `sent_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  KEY `idx_sent` (`sent_at`),
  KEY `idx_comp` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `review_invites` VALUES ('1','1','','Kwame Nkrumah','233245550118','INV-TEST-001','quick_favor','Test review invite message content','whatsapp','sent','2026-09-07 19:55:05','2026-09-07 19:55:05');

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(80) DEFAULT 'fa-solid fa-star',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_services_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `services` VALUES ('1','3','Housekeeping','How was the house keeping experience','fa-solid fa-dumbbell','0','active','2026-09-07 22:24:33');

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` VALUES ('1','site_name','Company Rating SaaS','2026-09-01 12:50:37');
INSERT INTO `settings` VALUES ('2','admin_email','admin@example.com','2026-09-01 12:50:37');
INSERT INTO `settings` VALUES ('3','ratings_per_page','10','2026-09-01 12:50:37');
INSERT INTO `settings` VALUES ('6','currency_symbol','$','2026-09-07 11:58:04');
INSERT INTO `settings` VALUES ('7','currency_code','USD','2026-09-07 11:58:05');
INSERT INTO `settings` VALUES ('8','currency_position','before','2026-09-07 11:58:06');
INSERT INTO `settings` VALUES ('9','mail_driver','smtp','2026-09-11 07:18:24');
INSERT INTO `settings` VALUES ('10','mail_from_name','Optibiz','2026-09-11 07:19:19');
INSERT INTO `settings` VALUES ('11','mail_from_email','admin@example.com','2026-09-11 07:19:19');
INSERT INTO `settings` VALUES ('12','smtp_host','smtp.gmail.com','2026-09-11 07:19:19');
INSERT INTO `settings` VALUES ('13','smtp_port','587','2026-09-11 07:18:25');
INSERT INTO `settings` VALUES ('14','smtp_encryption','tls','2026-09-11 07:18:25');
INSERT INTO `settings` VALUES ('15','smtp_username','','2026-09-11 07:19:19');
INSERT INTO `settings` VALUES ('16','smtp_password','','2026-09-11 07:19:19');

CREATE TABLE `site_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `customer_name` varchar(120) NOT NULL,
  `customer_email` varchar(120) NOT NULL,
  `customer_phone` varchar(30) DEFAULT NULL,
  `rating_id` int(11) DEFAULT NULL,
  `rating_value` tinyint(4) DEFAULT NULL,
  `is_following` tinyint(1) NOT NULL DEFAULT 0,
  `follow_platform` varchar(30) DEFAULT NULL,
  `is_liked` tinyint(1) NOT NULL DEFAULT 0,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `verification_type` varchar(30) DEFAULT NULL,
  `momo_ref` varchar(100) DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_sc_company_email` (`company_id`,`customer_email`),
  KEY `idx_sc_tenant` (`tenant_id`),
  KEY `idx_sc_company` (`company_id`),
  KEY `idx_sc_verified` (`company_id`,`is_verified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `social_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `account_ref` varchar(190) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `status` enum('connected','disabled') DEFAULT 'connected',
  `last_error` text DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `metadata` text DEFAULT NULL COMMENT 'JSON data for custom platforms',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_tenant_platform` (`tenant_id`,`platform`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `social_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `rating_id` int(11) DEFAULT NULL,
  `platform` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `status` enum('draft','published','failed') DEFAULT 'draft',
  `remote_id` varchar(190) DEFAULT NULL,
  `remote_url` varchar(255) DEFAULT NULL,
  `error` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_social_posts_tenant` (`tenant_id`),
  KEY `idx_social_posts_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `subscription_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `receipt_number` varchar(32) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) NOT NULL DEFAULT 'Bank Wire',
  `transaction_ref` varchar(100) DEFAULT NULL,
  `months_extended` int(11) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `recorded_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `invoice_id` int(11) DEFAULT NULL,
  `gateway_key` varchar(40) DEFAULT NULL,
  `gateway_reference` varchar(120) DEFAULT NULL,
  `currency` varchar(8) NOT NULL DEFAULT '',
  `fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `channel` varchar(40) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'confirmed',
  `source` varchar(20) NOT NULL DEFAULT 'offline',
  `payer_name` varchar(140) DEFAULT NULL,
  `payer_email` varchar(160) DEFAULT NULL,
  `payer_phone` varchar(40) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verified_by` varchar(120) DEFAULT NULL,
  `reject_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_pmt` (`tenant_id`),
  KEY `idx_receipt_num` (`receipt_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `subscription_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `max_ratings` int(11) NOT NULL,
  `max_customers` int(11) NOT NULL,
  `features` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `subscription_plans` VALUES ('1','Starter','29.99','100','10','Basic analytics, Email support, 10 customers, 100 ratings/month','active','2026-09-01 12:50:34');
INSERT INTO `subscription_plans` VALUES ('2','Professional','79.99','500','50','Advanced analytics, Priority support, 50 customers, 500 ratings/month, Custom branding','active','2026-09-01 12:50:34');
INSERT INTO `subscription_plans` VALUES ('3','Enterprise','199.99','9999','999','Full analytics suite, 24/7 support, Unlimited customers, Unlimited ratings, API access, White label','active','2026-09-01 12:50:34');

CREATE TABLE `subscription_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `current_plan_id` int(11) DEFAULT NULL,
  `requested_plan_id` int(11) NOT NULL,
  `direction` enum('upgrade','downgrade','same') DEFAULT 'upgrade',
  `note` text DEFAULT NULL,
  `status` enum('pending','approved','declined','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sub_req_tenant` (`tenant_id`),
  KEY `idx_sub_req_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `super_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `permissions` text DEFAULT NULL,
  `is_owner` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `super_admins` VALUES ('1','superadmin','$2y$10$6QY9LIHou.DYlfviSNxcL.X070pJP3F1SBn2lmuk5HHf3oddj8F8C','superadmin@example.com','2026-09-01 12:50:32','','1');

CREATE TABLE `system_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `portal` varchar(20) NOT NULL COMMENT 'superadmin or admin',
  `user_id` int(11) DEFAULT NULL,
  `user_label` varchar(120) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `entity_type` varchar(50) DEFAULT NULL COMMENT 'tenant, user, subscription, backup, etc.',
  `entity_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_logs_portal` (`portal`),
  KEY `idx_logs_user` (`portal`,`user_id`),
  KEY `idx_logs_action` (`action`),
  KEY `idx_logs_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_logs` VALUES ('1','superadmin','1','superadmin','test_action','Test description','test','1','','','2026-09-15 18:15:35');

CREATE TABLE `team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'staff',
  `permissions` varchar(1000) NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_team_username` (`username`),
  UNIQUE KEY `uniq_team_email` (`email`),
  KEY `idx_team_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `tenant_ad_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL DEFAULT 0,
  `meta_pixel_id` varchar(50) DEFAULT NULL,
  `meta_capi_token` text DEFAULT NULL,
  `meta_test_event_code` varchar(50) DEFAULT NULL,
  `google_ads_conversion_id` varchar(50) DEFAULT NULL,
  `google_ads_conversion_label` varchar(60) DEFAULT NULL,
  `tiktok_pixel_id` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_tenant_comp` (`tenant_id`,`company_id`),
  KEY `idx_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE `tenants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `public_id` varchar(32) DEFAULT NULL,
  `setup_token` varchar(128) DEFAULT NULL,
  `setup_token_expires` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `subscription_status` enum('trial','active','inactive','cancelled') DEFAULT 'trial',
  `subscription_price` decimal(10,2) DEFAULT 0.00,
  `subscription_start_date` date DEFAULT NULL,
  `subscription_end_date` date DEFAULT NULL,
  `auto_renew` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `logo` varchar(500) DEFAULT NULL,
  `banner` varchar(500) DEFAULT NULL,
  `public_page_settings` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `uniq_tenant_public_id` (`public_id`),
  KEY `plan_id` (`plan_id`),
  CONSTRAINT `tenants_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tenants` VALUES ('1','OPT-DPNN7JGS','','','','ABC Corporation','admin@abccorp.com','555-0101','abc_corporation','$2y$10$jEKODXNcBvreD9z/aAPVtueCcvNgfwO8/hqeEieYqDBLxjkd0Qtg2','2','active','79.99','2026-01-01','2026-12-31','1','2026-09-01 12:50:34','','','{\"primary_color\":\"#10b981\",\"secondary_color\":\"#059669\",\"star_color\":\"#f59e0b\",\"page_bg\":\"#f8fafc\",\"card_bg\":\"#ffffff\",\"card_border\":\"#e2e8f0\",\"text_color\":\"#0f172a\",\"muted_color\":\"#64748b\",\"layout_style\":\"modern_boxed\",\"header_layout\":\"standard\",\"review_layout\":\"tabs\",\"border_radius\":\"rounded\",\"theme_mode\":\"light\",\"show_banner\":1,\"show_breadcrumb\":1,\"show_verified_badge\":1,\"show_rating_dist\":1,\"show_services\":1,\"show_qa\":1,\"show_whatsapp\":1,\"show_gstore\":1,\"show_map\":1,\"custom_css\":\"\"}');
INSERT INTO `tenants` VALUES ('2','OPT-L739YUMW','','','','XYZ Industries','admin@xyzind.com','555-0102','xyz_industries','$2y$10$jEKODXNcBvreD9z/aAPVtueCcvNgfwO8/hqeEieYqDBLxjkd0Qtg2','1','active','29.99','2026-02-01','2027-02-01','1','2026-09-01 12:50:34','','','');
INSERT INTO `tenants` VALUES ('3','OPT-PJY9XXXQ','','','','Airport West Hotel','IT@airportwesthotel.com.gh','+233245834338','airport_west_hotel','$2y$10$NGEkhxOeVN.kIYKHI3OzQuh71Zq1.CsoRb1ixD0ZkXapXIl/NCCvu','1','active','29.99','2026-09-04','2027-09-16','1','2026-09-04 11:06:21','uploads/tenant_logo_3_1788528249.png','','{\"primary_color\":\"#10b981\",\"secondary_color\":\"#059669\",\"star_color\":\"#f59e0b\",\"page_bg\":\"#f8fafc\",\"card_bg\":\"#ffffff\",\"card_border\":\"#e2e8f0\",\"text_color\":\"#0f172a\",\"muted_color\":\"#64748b\",\"layout_style\":\"modern_boxed\",\"header_layout\":\"standard\",\"review_layout\":\"tabs\",\"border_radius\":\"rounded\",\"theme_mode\":\"light\",\"show_banner\":1,\"show_breadcrumb\":1,\"show_verified_badge\":1,\"show_rating_dist\":1,\"show_services\":1,\"show_qa\":1,\"show_whatsapp\":1,\"show_gstore\":1,\"show_map\":1,\"custom_css\":\"\"}');
INSERT INTO `tenants` VALUES ('4','OPT-3VBJY4KQ','2597b9fab9a65aff679b7de1aac2984e2a1f8a111d57e72f03e41803f804e15e','2026-09-13 09:16:01','','Test Flow Company 229','test_quote_8e5be436@example.com','+1234567890','test_flow_company_229','0','1','trial','29.99','2026-09-11','2026-10-11','1','2026-09-11 07:16:01','','','');
INSERT INTO `tenants` VALUES ('5','OPT-28DC7UA4','c0ecbe45b49477feda2b9b97adde5704961a9ec25e7db38fb1c5bbd46d7805cd','2026-09-13 09:16:45','','Test Flow Company 386','test_quote_27a75588@example.com','+1234567890','test_flow_company_386','0','1','trial','29.99','2026-09-11','2026-10-11','1','2026-09-11 07:16:45','','','');
INSERT INTO `tenants` VALUES ('6','OPT-WYZGPRXP','1d449407f3e28328de71bfeacb7c2bebe636acf031b4d4e853f8f670492ed23f','2026-09-13 09:17:04','','Test Flow Company 155','test_quote_c9f698ac@example.com','+1234567890','test_flow_company_155','0','1','active','29.99','2026-09-11','2027-10-11','1','2026-09-11 07:17:04','','','');

CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_token` varchar(64) NOT NULL,
  `portal` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_label` varchar(120) DEFAULT NULL,
  `user_kind` varchar(20) NOT NULL DEFAULT 'admin',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_seen_at` timestamp NULL DEFAULT NULL,
  `logged_out_at` timestamp NULL DEFAULT NULL,
  `logout_reason` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_sessions_token` (`session_token`),
  KEY `idx_user_sessions_user` (`portal`,`user_id`,`logged_out_at`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_sessions` VALUES ('1','19770057173cfa27162417a3d31876b97bfcb70312b59e7293cb90511d7a0840','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-07 10:43:12','2026-09-07 10:54:54','','');
INSERT INTO `user_sessions` VALUES ('2','be5eb27cf2e5e9c42fa16ffb1c6e223bfa37db42a514052223a2e88cfceab4b2','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-07 10:56:51','2026-09-07 13:05:41','2026-09-07 13:05:54','user');
INSERT INTO `user_sessions` VALUES ('3','0efb8f64f3a46ea0e191811e3e9f03dcb860f8e1461863c598fc34960eae2aa3','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-07 13:06:06','2026-09-07 13:06:06','','');
INSERT INTO `user_sessions` VALUES ('4','e3f7097231f1b159bb06a367c115be535aa18e5f38c285494a2142a1aa194048','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-07 13:12:19','2026-09-07 13:54:20','2026-09-07 16:03:56','idle');
INSERT INTO `user_sessions` VALUES ('5','ee97b8e45909286b053d7ca26dd7794cca30e6395fd46921e3f1a1600e4aa343','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-07 16:04:46','2026-09-07 16:14:24','','');
INSERT INTO `user_sessions` VALUES ('6','803994eae7f8946a658e5fb05da7c2a3a3487672605a2193ed8f2ddd078bb668','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','2026-09-07 16:21:40','2026-09-07 17:15:45','2026-09-07 17:16:36','user');
INSERT INTO `user_sessions` VALUES ('7','d2276a021bd871a867d2d135dfb925970b5dcc72cd03102344581fad500760df','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-07 16:21:52','2026-09-07 22:24:33','2026-09-08 08:16:59','idle');
INSERT INTO `user_sessions` VALUES ('8','a1a34812501c9a02f025643970c77dc877349fc6297bf592d4f10b65124f3fb5','admin','1','Workspace user','admin','','','2026-09-07 17:47:03','2026-09-07 17:47:03','','');
INSERT INTO `user_sessions` VALUES ('9','47f0eef19c0236f58e365c5e1c7a684e52ff2289073e0e3715b59d8c4efee9d9','admin','1','Workspace user','admin','','','2026-09-07 17:47:14','2026-09-07 17:47:14','','');
INSERT INTO `user_sessions` VALUES ('10','0de645e54eaf79cc88d63cd7a57c743c26e28584b3a99d90dc42c4b1c9e0859d','admin','1','Workspace user','admin','','','2026-09-07 17:55:05','2026-09-07 17:55:05','','');
INSERT INTO `user_sessions` VALUES ('11','90bbf1ed0895d85c3d15217ea998c9decd7f674b4633f9b1df5790fbdc7bb467','admin','1','Workspace user','admin','','','2026-09-07 18:02:37','2026-09-07 18:02:37','','');
INSERT INTO `user_sessions` VALUES ('12','ccb8e29444048c0559a9a403d48500cb52c20d77b4b47f01e3cd2cfbe06a4367','admin','1','Workspace user','tenant','','','2026-09-07 20:20:40','2026-09-07 20:20:40','','');
INSERT INTO `user_sessions` VALUES ('13','3f02d2de3c9bdefa654b555322435c12d2583aed4ac17aa337f02f8a1473b809','admin','1','admin','admin','','','2026-09-10 18:27:52','2026-09-10 18:27:52','','');
INSERT INTO `user_sessions` VALUES ('14','1a7c61a0e4ddd28b271bf07f41c2e260052c5a5bd67afa5e7c3d6eeee6e6896b','admin','1','admin','admin','','','2026-09-10 18:28:06','2026-09-10 18:28:06','','');
INSERT INTO `user_sessions` VALUES ('15','a6f8fca980e23011ea2cefacace433ede7a5e0e38dfd9ab37763ee5f878144dd','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-10 19:40:42','2026-09-10 21:20:37','','');
INSERT INTO `user_sessions` VALUES ('16','336dad8e6351d84bb161c9d0d7f6d02279ad787428baa5b4d562ff78138629bb','superadmin','1','admin','super_admin','','','2026-09-10 20:11:55','2026-09-10 20:11:55','','');
INSERT INTO `user_sessions` VALUES ('17','4e34629d38d3cefbde584dfa08b41110921e1727f0c29c056ce9e70b7dd409b0','superadmin','1','admin','super_admin','','','2026-09-10 20:12:13','2026-09-10 20:12:13','','');
INSERT INTO `user_sessions` VALUES ('18','6a60c74817af0492062f0629f738c5ea7705507c56379f1af1b218f6422c82ec','superadmin','1','admin','super_admin','','','2026-09-10 20:12:30','2026-09-10 20:12:30','','');
INSERT INTO `user_sessions` VALUES ('19','0184c25bfa5a3c251aef4365bd3c26b7b8575c3994ec758b495088f619f8f333','superadmin','1','admin','super_admin','','','2026-09-10 20:12:48','2026-09-10 20:12:48','','');
INSERT INTO `user_sessions` VALUES ('20','741b120b1701fdf35d1bb4ee9d3c2883bdbd49d64b9ad4736f86104551ab224e','superadmin','1','admin','super_admin','','','2026-09-10 20:12:58','2026-09-10 20:12:58','','');
INSERT INTO `user_sessions` VALUES ('21','bf29718b635289258eb8978765eafc41c918fa2bd603c1750cb3d86a713bb475','superadmin','1','admin','super_admin','','','2026-09-10 20:13:13','2026-09-10 20:13:13','','');
INSERT INTO `user_sessions` VALUES ('22','1dee7ef19dadfad141e3628343a89270d179d00eab764b5aff631ad0cf232b2a','superadmin','1','admin','super_admin','','','2026-09-10 20:13:25','2026-09-10 20:13:25','','');
INSERT INTO `user_sessions` VALUES ('23','e9f1f8a342dc05d5171414c6eaebc476affa3a0cb09e2b199d1c01170f6705f5','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-10 21:22:50','2026-09-10 21:22:50','2026-09-11 07:04:53','idle');
INSERT INTO `user_sessions` VALUES ('24','ad7005c307d1c4e91286e5a8735ceaeae6c5ae2501d0977a2ca33c1da299e9e6','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','2026-09-11 07:54:27','2026-09-11 07:54:27','','');
INSERT INTO `user_sessions` VALUES ('25','096c206f5338fc2945b1910e0ff7866fb347172bbb3b6ac3b5215b51d92110ac','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-14 11:16:34','2026-09-14 16:35:26','2026-09-14 16:35:35','user');
INSERT INTO `user_sessions` VALUES ('26','e7ee822fdfc1a77676496784b334cd0f9bc3125537ae566c792b5782b63afc7f','admin','1','Abena Mensah','team','','','2026-09-14 13:11:45','2026-09-14 13:11:45','','');
INSERT INTO `user_sessions` VALUES ('27','0f5da9971e037861ab415c2997fcf45fd72cd86e6c2f347e4c366a867cc7241d','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-14 17:17:40','2026-09-14 17:17:40','2026-09-14 17:17:51','user');
INSERT INTO `user_sessions` VALUES ('28','7672ad92213638ab6206acfb00d22d8e39868ca520a4505f78ba0e910c3f4b89','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-14 17:18:22','2026-09-14 17:18:22','2026-09-14 17:18:44','user');
INSERT INTO `user_sessions` VALUES ('29','c3a57e3c6fac1cc4fa62fda8e5a42eb6b56ebccc29a72ec74ecd136b7ef20723','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-14 17:19:30','2026-09-14 17:19:30','2026-09-14 17:44:01','user');
INSERT INTO `user_sessions` VALUES ('30','d0830c5ed94148cee2f4019a57b3a359735c026f1b4b3e6fc55c39b1781633bc','superadmin','1','superadmin','super_admin','::1','curl/8.21.0','2026-09-14 17:48:05','2026-09-14 17:49:25','','');
INSERT INTO `user_sessions` VALUES ('31','b5b47d481c78f31cc91e7bc63de157ea98d9fedde2367e00b8b1eb54f093d837','superadmin','1','superadmin','super_admin','::1','curl/8.21.0','2026-09-14 17:53:39','2026-09-14 17:53:39','','');
INSERT INTO `user_sessions` VALUES ('32','c9806d522f56750aac848da0ddc79c7fb2c1525a85cdd713a7ddbf29e40c5858','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-14 18:03:33','2026-09-14 18:14:29','2026-09-14 21:30:41','idle');
INSERT INTO `user_sessions` VALUES ('33','b087e35d72ef67e83131362c0023cb5d01cb4898da77ae54c061f0df5b994838','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-14 21:30:56','2026-09-14 21:32:05','2026-09-15 07:31:31','idle');
INSERT INTO `user_sessions` VALUES ('34','049a2362a266d64b0d8d3b54f323d8ee045cb3263375682a9df1f522b95836ca','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 07:32:41','2026-09-15 10:54:51','2026-09-15 14:24:30','idle');
INSERT INTO `user_sessions` VALUES ('35','c2c524ed8b4d975242e6b9e35e3e94d7d903765a8205bd8d1c69b2699de734fe','admin','1','Test Tenant','tenant','','','2026-09-15 09:00:39','2026-09-15 09:00:39','','');
INSERT INTO `user_sessions` VALUES ('36','55c441febd5a9ebdf161907bb1668f5d792e8d45f369c3c53a9bfa9fef9dc10e','admin','3','Airport West Hotel','tenant','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 14:25:52','2026-09-15 15:14:12','','');
INSERT INTO `user_sessions` VALUES ('37','4a3e4fa0e9a06fda1871e915145df253f4eab1c961d371ed3af4ca09404502e7','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 15:17:56','2026-09-15 15:20:21','2026-09-15 16:11:27','idle');
INSERT INTO `user_sessions` VALUES ('38','302cddba6627c6bc5138331ec5cac800b2743196254e130a2db34170e4019e21','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 16:11:38','2026-09-15 16:11:38','2026-09-15 17:55:51','idle');
INSERT INTO `user_sessions` VALUES ('39','9e98ac895a52b94abce7c626512ffb4662872754e8b538d6efbbd001a81327f7','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 17:55:57','2026-09-15 17:59:39','2026-09-15 18:30:45','idle');
INSERT INTO `user_sessions` VALUES ('40','51a25248bc504b533ba05163ac790ec3bb2f1f4affe35243fad05887630b9ff8','superadmin','1','superadmin','super_admin','','','2026-09-15 18:25:28','2026-09-15 18:25:28','','');
INSERT INTO `user_sessions` VALUES ('41','b358742afe0de3a7cee9eda77933c9c39459307baffbca801668befa3f49ee62','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 18:31:15','2026-09-15 18:46:08','','');
INSERT INTO `user_sessions` VALUES ('42','93bae9d8c49d9a8518e1cd8723be90065d11689c1264a7dc0f6b942c350a20d2','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 18:48:21','2026-09-15 18:48:21','2026-09-15 19:22:43','idle');
INSERT INTO `user_sessions` VALUES ('43','c8d65b22134b56dcfff8d85e48a8086843c56cc897d751ce3fd232a898db1239','superadmin','1','superadmin','super_admin','','','2026-09-15 19:00:17','2026-09-15 19:00:17','','');
INSERT INTO `user_sessions` VALUES ('44','2b59cdd8a8b8d9b624f23eafcd8b514ffa491aa6b1ff5a1047c113f4daffb63c','superadmin','1','superadmin','super_admin','','','2026-09-15 19:04:10','2026-09-15 19:04:10','','');
INSERT INTO `user_sessions` VALUES ('45','dc3aa0b2c88188d8aacaf7f90504f3e2183d1bf4de242742da999298a6f0cf38','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 19:22:49','2026-09-15 19:22:49','2026-09-15 20:03:03','idle');
INSERT INTO `user_sessions` VALUES ('46','3094af65797cbc4ec8357e90e25e3a2903e048612c58e1fd943d741963fd177e','superadmin','1','superadmin','super_admin','','','2026-09-15 19:47:09','2026-09-15 19:47:09','','');
INSERT INTO `user_sessions` VALUES ('47','36fe952e906a7e3a0b37abe2f4df4f9ef53ffd173a6a6d85fee72c6df7b70314','superadmin','1','superadmin','super_admin','','','2026-09-15 19:58:17','2026-09-15 19:58:17','','');
INSERT INTO `user_sessions` VALUES ('48','decafc8341f536cb3f1507df13593885415040ab9f10560e46adf78bc1aea2ca','superadmin','1','superadmin','super_admin','','','2026-09-15 19:59:44','2026-09-15 19:59:44','','');
INSERT INTO `user_sessions` VALUES ('49','ef383cf7dfb8158b45205d8a491927bc744304fa8517c76a9fd0a7fe6d1a634e','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-15 20:03:06','2026-09-15 20:08:36','2026-09-16 09:33:36','idle');
INSERT INTO `user_sessions` VALUES ('50','34ce7917af8df6f41f92b5cd809afd2f0016750f24a628cefe12d138c02ffd4c','superadmin','1','superadmin','super_admin','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','2026-09-16 09:34:00','2026-09-16 09:59:50','','');
INSERT INTO `user_sessions` VALUES ('51','d405f140c22c89306ee031053cd50d0c9efcff8d9601e8f954b7d2d29b3e8ccd','superadmin','1','superadmin','super_admin','','','2026-09-16 09:40:49','2026-09-16 09:40:49','','');
INSERT INTO `user_sessions` VALUES ('52','a5d39941fdc1a322a8c0956188a1427cb2f8256e8f9fa57f130383d08a7c9864','superadmin','1','superadmin','super_admin','','','2026-09-16 09:41:18','2026-09-16 09:41:18','','');
INSERT INTO `user_sessions` VALUES ('53','04dceaac6db527e3edcbd816ef09a14aa5d0072ca22b19207a4701b7fa67d8f5','superadmin','1','superadmin','super_admin','','','2026-09-16 09:44:52','2026-09-16 09:44:52','','');
INSERT INTO `user_sessions` VALUES ('54','5a59d69109fa6f71271f94a8d82f63dd59ff29ac9a102260ef0add4e436ef8ef','superadmin','1','admin','super_admin','','','2026-09-16 09:54:07','2026-09-16 09:54:07','','');

